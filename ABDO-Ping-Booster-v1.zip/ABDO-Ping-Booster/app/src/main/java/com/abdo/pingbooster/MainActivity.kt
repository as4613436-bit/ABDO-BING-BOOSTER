package com.abdo.pingbooster

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var ping: TextView
    private lateinit var dns: TextView
    private lateinit var network: TextView
    private lateinit var testButton: Button

    private val bg = Color.rgb(31, 34, 39)
    private val panel = Color.rgb(47, 51, 58)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 195, 202)
    private val green = Color.rgb(92, 210, 145)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        updateNetworkType()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "ABDO"
            textSize = 34f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PING BOOSTER"
            textSize = 13f
            letterSpacing = 0.22f
            setTextColor(green)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())
        addSpace(root, 28)

        status = label("جاهز لاختبار الاتصال")
        root.addView(status, matchWrap())
        addSpace(root, 12)

        ping = valueCard("زمن الاتصال", "— ms")
        root.addView(ping, matchWrap())
        addSpace(root, 10)
        dns = valueCard("اختبار DNS", "لم يتم الاختبار")
        root.addView(dns, matchWrap())
        addSpace(root, 10)
        network = valueCard("نوع الشبكة", "جارٍ التعرّف...")
        root.addView(network, matchWrap())
        addSpace(root, 22)

        testButton = Button(this).apply {
            text = "ابدأ فحص الاتصال"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.rgb(20, 30, 25))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { runDiagnostics() }
        }
        root.addView(testButton, LinearLayout.LayoutParams(-1, dp(54)))
        addSpace(root, 14)

        val note = TextView(this).apply {
            text = "ملاحظة: هذا التطبيق يقيس جودة الاتصال ويختبر الوصول إلى الخوادم. لا يستطيع ضمان خفض البنج أو تغيير DNS للهاتف تلقائيًا."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(muted)
        gravity = Gravity.CENTER
    }

    private fun valueCard(title: String, initial: String) = TextView(this).apply {
        text = "$title\n$initial"
        textSize = 17f
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(17), dp(12), dp(17))
        setBackgroundColor(panel)
    }

    private fun runDiagnostics() {
        testButton.isEnabled = false
        status.text = "جارٍ فحص الاتصال..."
        ping.text = "زمن الاتصال\nجارٍ القياس..."
        dns.text = "اختبار DNS\nجارٍ القياس..."
        updateNetworkType()

        worker.execute {
            val samples = mutableListOf<Long>()
            var successes = 0
            repeat(4) {
                val ms = tcpLatency("1.1.1.1", 443, 2500)
                if (ms >= 0) { samples.add(ms); successes++ }
            }
            val avg = if (samples.isNotEmpty()) samples.average().toLong() else -1L
            val dnsMs = try {
                val start = System.nanoTime()
                InetAddress.getByName("www.google.com")
                ((System.nanoTime() - start) / 1_000_000L)
            } catch (_: Exception) { -1L }

            mainHandler.post {
                ping.text = "زمن الاتصال\n${if (avg >= 0) "$avg ms" else "تعذّر الاتصال"}"
                dns.text = "اختبار DNS\n${if (dnsMs >= 0) "$dnsMs ms" else "فشل حل الاسم"}"
                status.text = "اكتملت 4 محاولات — نجاح $successes/4"
                testButton.isEnabled = true
            }
        }
    }

    private fun tcpLatency(host: String, port: Int, timeout: Int): Long {
        return try {
            Socket().use { socket ->
                val start = System.nanoTime()
                socket.connect(InetSocketAddress(host, port), timeout)
                (System.nanoTime() - start) / 1_000_000L
            }
        } catch (_: Exception) { -1L }
    }

    private fun updateNetworkType() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val kind = when {
            caps == null -> "لا يوجد اتصال نشط"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "بيانات الهاتف"
            else -> "اتصال آخر"
        }
        network.text = "نوع الشبكة\n$kind"
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
